let opCards = document.querySelector(".opCards");
let myCards = document.querySelector(".myCards");
let myWar = document.querySelector(".myWar");
let opWar = document.querySelector(".opWar");
let whoWon = document.querySelector(".whoWon");
let start = document.getElementById("start");
let myRe = document.querySelector(".myReCards");
let opRe = document.querySelector(".opReCards");
let rematch = document.getElementById("rematch");
let plate = document.querySelector(".warplate");
rematch.addEventListener("click", () => {
  location.reload(true);
});
let myArr = [];
let opArr = [];

if (opCards && myCards && myWar && opWar && whoWon && start) {
  start.addEventListener("click", () => {
    const random = (min, max) => {
      min = Math.ceil(min); // round up
      max = Math.floor(max); // round down
      return Math.floor(Math.random() * (max - min + 1) + min);
    };
    for (let i = 1; i <= 10; i++) {
      let card = document.createElement("div");
      card.id = random(2, 14);
      card.innerHTML = card.id;
      card.className = "card";
      if (card.id == 11) {
        card.innerHTML = "J";
      }
      if (card.id == 12) {
        card.innerHTML = "Q";
      }
      if (card.id == 13) {
        card.innerHTML = "K";
      }
      if (card.id == 14) {
        card.innerHTML = "A";
      }
      myArr.push(card);
      myCards.appendChild(card);
      setTimeout(() => {
        card.style.backgroundColor = "blue";
      }, 500);
      setTimeout(() => {
        card.style.backgroundColor = "gray";
      }, 1000);
      setTimeout(() => {
        card.style.backgroundColor = "blue";
      }, 1500);
      setTimeout(() => {
        card.style.backgroundColor = "gray";
      }, 2000);
      setTimeout(() => {
        card.style.backgroundColor = "blue";
      }, 2500);
      setTimeout(() => {
        card.style.backgroundColor = "gray";
      }, 3000);
      card.addEventListener("click", () => {
        war();
      });
    }
    for (let i = 1; i <= 10; i++) {
      let card = document.createElement("div");
      card.id = random(2, 14);
      card.innerHTML = card.id;
      card.className = "card";
      if (card.id == 11) {
        card.innerHTML = "J";
      }
      if (card.id == 12) {
        card.innerHTML = "Q";
      }
      if (card.id == 13) {
        card.innerHTML = "K";
      }
      if (card.id == 14) {
        card.innerHTML = "A";
      }
      opArr.push(card);
      opCards.appendChild(card);
    }
  });

  const war = () => {
    let z = myArr.length - 1;
    myWar.appendChild(myArr[z]);
    myArr[z].style.backgroundColor = "darkgreen";
    opWar.appendChild(opArr[z]);
    myArr.splice(z);
    opArr.splice(z);

    checkWhoWon();
  };

  const checkWhoWon = () => {
    let myCheck = document.querySelector(".myWar>.card");
    let opCheck = document.querySelector(".opWar>.card");
    if (+myCheck.id > +opCheck.id) {
      whoWon.innerHTML = "Yow Won";
      whoWon.style.color = "white";
      setTimeout(() => {
        myRe.appendChild(myCheck);
        myRe.appendChild(opCheck);
        whoWon.innerHTML = "";
        checkStatus();
      }, 1500);
    } else if (+myCheck.id < +opCheck.id) {
      whoWon.innerHTML = "Yow lose";
      whoWon.style.color = "red";
      setTimeout(() => {
        opRe.appendChild(myCheck);
        opRe.appendChild(opCheck);
        whoWon.innerHTML = "";
        checkStatus();
      }, 1500);
    } else if (+myCheck.id == +opCheck.id) {
      whoWon.innerHTML = "Drow";
      whoWon.style.color = "rgb(164, 164, 1)";
      setTimeout(() => {
        myRe.appendChild(myCheck);
        opRe.appendChild(opCheck);
        whoWon.innerHTML = "";
        checkStatus();
      }, 1500);
    }
  };

  const checkStatus = () => {
    let popUp = document.querySelector(".popUp");
    let checkGum = document.querySelectorAll(".myCards>.card");
    let newarr = [];
    for (let i of checkGum) {
      newarr.push(i);
    }
    if (+newarr.length == 0) {
      myArr = [];
      opArr = [];
      let allNew = document.querySelectorAll(".myReCards>.card");
      let allNewop = document.querySelectorAll(".opReCards>.card");
      for (let x of allNew) {
        myCards.appendChild(x);
        myArr.push(x);
      }
      for (let z of allNewop) {
        opCards.appendChild(z);
        opArr.push(z);
      }
      let num1 = myArr.length / 2;
      let num2 = opArr.length / 2;
      if (+myArr.length < +opArr.length) {
        plate.style.opacity = "0.3";
        popUp.innerHTML = `You Lose The Game! <br> <br> Socre: ${num1} Vs ${num2}<br>`;
        popUp.setAttribute("style", "display:block; color:red");
        popUp.appendChild(rematch);
      }
      if (+myArr.length > +opArr.length) {
        plate.style.opacity = "0.3";
        popUp.innerHTML = `You Won The Game! <br> <br> Socre: ${num1} Vs ${num2}<br>`;
        popUp.setAttribute("style", "display:block; color:green");
        popUp.appendChild(rematch);
      }
      if (+myArr.length == +opArr.length) {
        plate.style.opacity = "0.3";
        popUp.innerHTML = `Game Drow! <br> <br> Socre: ${num1} Vs ${num2}<br>`;
        popUp.setAttribute("style", "display:block; color:rgb(164, 164, 1)");
        popUp.appendChild(rematch);
      }
    }
  };
}
